# CodeIgniter-Template

CodeIgniter-Template is a Template library that helps your build complex views with CodeIgniter.
It has logic to work with themes & modules and helps add your title, meta-data, breadcrumbs and partial views.


## Requirements

1. PHP 5.2+
2. CodeIgniter 2.0.3

## Documentation

Look in user_guide or <a href="http://philsturgeon.co.uk/demos/codeigniter-template/user_guide/">click here</a>.
Yeah, I actually wrote some documentation! :-o